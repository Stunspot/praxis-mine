'use strict';
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const token=new URLSearchParams(location.hash.slice(1)).get('token')||sessionStorage.getItem('praxisToken');
sessionStorage.setItem('praxisToken',token||'');history.replaceState(null,'',location.pathname);
let records=[],selected=null,formAction,view='horizon',filter='',trailKind='',pins=new Set(),dataHome='',loaded=false,sourceFocus='';
const dispositions=[['triage','Unassessed','Start with the evidence'],['quarry','Quarry','Extract the useful part'],['adapt','Adapt','Make the mechanism fit'],['pilot','Pilot','Run a bounded test'],['monitor','Monitor','Wait for new evidence'],['reject','Reject','Keep the reason'],['adopt','Adopt','Recorded acceptance']];
const title=r=>{if(!r)return 'Untitled record';if(r.payload.title)return r.payload.title;if(r.record_type==='evaluation'){const candidate=records.find(x=>x.record_type==='candidate'&&x.payload.candidate_key===r.payload.candidate_key);return (candidate?.payload.title||r.payload.candidate_key||'Finding')+' · evaluation'}if(r.record_type==='run'){const source=records.find(x=>x.record_type==='source'&&x.payload.source_key===r.payload.source_key);return (source?.payload.title||r.payload.source_key||'Source')+' · '+(r.payload.route||'mining')+' run'}return r.payload.candidate_key||r.payload.run_key||r.payload.evaluation_key||'Untitled record'};
const text=v=>typeof v==='object'?JSON.stringify(v,null,2):String(v??'');
const tags=r=>r?.payload.tags&&typeof r.payload.tags==='object'&&!Array.isArray(r.payload.tags)?r.payload.tags:{};
const date=r=>r.payload.evaluated_at||r.effective_at||r.updated_at||r.created_at||'';
const day=s=>s?new Date(s).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}):'Date not recorded';
const evaluations=r=>r?.payload.candidate_key?records.filter(x=>x.record_type==='evaluation'&&x.payload.candidate_key===r.payload.candidate_key).sort((a,b)=>date(b).localeCompare(date(a))):[];
const currentEvaluation=r=>evaluations(r).find(e=>e.current_for_candidate===true);
const latest=r=>currentEvaluation(r)?.payload;
const activityDate=r=>[date(r),...evaluations(r).map(date)].sort().at(-1)||'';
const sourceOf=r=>{const key=r?.payload.source_key||(r?.record_type==='evaluation'?records.find(x=>x.record_type==='candidate'&&x.payload.candidate_key===r.payload.candidate_key)?.payload.source_key:undefined);return records.find(x=>x.record_type==='source'&&x.payload.source_key===key)};
function disposition(r){return r.record_type==='candidate'?(latest(r)?.disposition||'triage'):(r.record_type==='evaluation'&&r.current_for_candidate===false?'historical · ':'')+(r.payload.disposition||'')}
function short(v,n=180){const s=text(v);return s.length>n?s.slice(0,n).replace(/\s+\S*$/,'')+'…':s}
function status(s,error=false){$('#status').textContent=s;$('#status').classList.toggle('error',error)}
async function api(path,data={}){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Workspace-Token':token},body:JSON.stringify(data)});if(!r.ok){let message='The ledger could not complete this request.';try{message=(await r.json()).error||message}catch{}throw Error(message)}return r.headers.get('content-type')?.includes('application/json')?r.json():r.blob()}
async function act(f){try{await f()}catch(e){status(e.message,true)}}
function storageKey(k){return 'praxis:'+dataHome+':'+k}
async function refresh(){
 $('#refresh').disabled=true;
 try{const d=await api('list');records=d.records;dataHome=d.data_root;$('#home').textContent=dataHome;
 if(!loaded){try{pins=new Set(JSON.parse(localStorage.getItem(storageKey('pins'))||'[]'));const id=localStorage.getItem(storageKey('selected'));selected=records.find(r=>r.record_id===id)}catch{}loaded=true}
 pins=new Set([...pins].filter(id=>records.some(r=>r.record_type==='candidate'&&r.record_id===id)));
 selected=records.find(r=>r.record_id===selected?.record_id)||records.filter(r=>r.record_type==='candidate').sort((a,b)=>activityDate(b).localeCompare(activityDate(a)))[0]||null;
 draw();detail();status('Ledger current · Discovery is not acceptance.');
 }catch(e){status(e.message,true);if(!loaded){$('#list').innerHTML='<div class="empty-state error-state"><p class="eyebrow">LEDGER UNAVAILABLE</p><h3>The mine could not open.</h3><p>'+esc(e.message)+'</p><p>Use Refresh to retry. If the launch session expired, reopen Praxis Mine with Open.cmd.</p></div>';$('#detail').innerHTML='<div class="empty-state"><h2>Your findings have not been loaded.</h2><p>The ledger remains on disk. Reopen through the launcher to restore this session.</p></div>'}}
 finally{$('#refresh').disabled=false}
}
function matches(r,q){const s=sourceOf(r);return (JSON.stringify(r.payload)+' '+date(r)+' '+(s?JSON.stringify(s.payload):'')+' '+evaluations(r).map(x=>JSON.stringify(x.payload)).join(' ')).toLowerCase().includes(q)}
function filtered(){const q=$('#search').value.toLowerCase().trim();return records.filter(r=>(view!=='trail'?r.record_type==='candidate':(!trailKind||r.record_type===trailKind))&&(!filter||disposition(r)===filter)&&(!q||matches(r,q))).sort((a,b)=>$('#order').value==='title'?title(a).localeCompare(title(b)):$('#order').value==='old'?(view!=='trail'?activityDate(a):date(a)).localeCompare(view!=='trail'?activityDate(b):date(b)):(view!=='trail'?activityDate(b):date(b)).localeCompare(view!=='trail'?activityDate(a):date(a)))}
function draw(){
 document.body.dataset.view=view;
 const sourceScroll=$('.source-strip')?.scrollLeft||0;
 const cs=records.filter(r=>r.record_type==='candidate'),ss=records.filter(r=>r.record_type==='source'),es=records.filter(r=>r.record_type==='evaluation');
 const snap=document.body.dataset.skin==='snapframe';
 $('#collection-summary').innerHTML=[[cs.length,'findings'],[ss.length,'sources'],[es.length,'evaluations']].map(([n,l])=>`<div class="stat"><strong>${n}</strong><span>${l}</span></div>`).join('');
 $('#seams').innerHTML=`<button class="seam all-seams" data-disposition="" aria-pressed="${!filter}"><span class="seam-count">${cs.length}</span><span class="seam-name">All findings</span></button>`+dispositions.map(([id,label,hint])=>`<button class="seam" data-disposition="${id}" aria-pressed="${filter===id}"><span class="seam-count">${cs.filter(r=>disposition(r)===id).length}</span><span class="seam-name">${label}</span><span class="seam-hint">${hint}</span></button>`).join('');
 $('#seams').querySelectorAll('button').forEach(b=>b.onclick=()=>{filter=filter===b.dataset.disposition?'':b.dataset.disposition;draw();$('#seams').querySelector(`[data-disposition="${b.dataset.disposition}"]`).focus()});
 $('#collection-title').textContent=view==='horizon'?'The decision field.':view==='findings'?(snap?'Trace the useful part.':'The extraction gallery.'):'The work, over time.';
 $('#collection-kicker').textContent=view==='horizon'?'RECORDED DISPOSITIONS / REAL NEXT TESTS':view==='findings'?(snap?'SNAPFRAME / SOURCE → MECHANISM → NEXT TEST':'BLACKGLASS — CRIMSON / EXTRACTED POSSIBILITIES'):'CHRONOLOGY / ORIGINAL RECORDED DATES';
 $('#stage-intro').textContent=view==='horizon'?'See which findings have a next test, what still lacks an evaluation, and the source behind each idea. Categories are recorded judgments, not steps in a pipeline.':view==='findings'?(snap?'Follow a source into its findings. See the judgment and the test that could change it.':'Browse what each source yielded. Bring the useful pieces to the bench.'):'Sources, findings and judgments retain their own dates and provenance.';
 $('#view-findings').textContent=snap?'Evidence circuit':'Source gallery';
 $('#active-filters').innerHTML=(filter?`<button class="filter-chip" id="clear-filter">${esc(filter)} × Clear filter</button>`:'')+(view==='trail'?`<label class="trail-kind">Show<select id="kind"><option value="">All activity</option>${['candidate','source','run','evaluation'].map(k=>`<option value="${k}" ${trailKind===k?'selected':''}>${k}</option>`).join('')}</select></label>`:'');
 if($('#clear-filter'))$('#clear-filter').onclick=()=>{filter='';draw()};if($('#kind'))$('#kind').onchange=e=>{trailKind=e.target.value;draw()};
 const rs=filtered();$('#record-count').textContent=rs.length+' / '+(view!=='trail'?cs.length:records.length)+(view!=='trail'?' findings':' records');
 if(!rs.length && !(snap&&view==='findings'&&!cs.length&&ss.length&&!filter&&!$('#search').value.trim())){$('#list').innerHTML=`<div class="empty-state"><p class="eyebrow">${records.length?'NO MATCHES':'A NEW EXCAVATION'}</p><h2>${records.length?'No findings in this view.':'Bring the first finding to the bench.'}</h2><p>${records.length?'Broaden the search or clear the filters. Your collection is still here.':'Use Ledger tools to record a source and finding, or import a native manifest from earlier mining work.'}</p>${records.length?'<button id="clear-all">Show the whole collection</button>':'<button id="first-source">Record the first source</button><button id="first-import">Import a mining manifest</button>'}</div>`;if($('#clear-all'))$('#clear-all').onclick=()=>{$('#search').value='';filter='';trailKind='';draw()};if($('#first-source'))$('#first-source').onclick=()=>editRecord(null,'source');if($('#first-import'))$('#first-import').onclick=()=>$('#file').click();if(view!=='trail'&&!cs.length&&ss.length){$('#list').innerHTML='<div class="empty-state"><p class="eyebrow">SOURCES REGISTERED</p><h2>Find the useful part.</h2><p>Your source records are ready. Record a finding to connect a mechanism to its source.</p><button id="first-candidate">Record the first finding</button></div>';$('#first-candidate').onclick=()=>editRecord(null,'candidate')}}
 else if(view==='trail')drawTrail(rs);
 else $('#list').innerHTML=view==='horizon'?renderHorizon(rs):(snap?renderSnapframe(rs):renderBlackglass(rs));
 $('#list').querySelectorAll('[data-id]').forEach(b=>b.onclick=()=>select(b.dataset.id));
 $('#list').querySelectorAll('[data-pin]').forEach(b=>b.onclick=()=>togglePin(b.dataset.pin));
 $('#list').querySelectorAll('[data-expand]').forEach(b=>b.onclick=()=>{horizonExpanded.add(b.dataset.expand);draw();$('#list').querySelector('[data-disposition="'+CSS.escape(b.dataset.expand)+'"] .horizon-group-head')?.scrollIntoView({block:'start'})});
 $('#list').querySelectorAll('[data-source-focus]').forEach(b=>b.onclick=()=>{sourceFocus=b.dataset.sourceFocus;draw();$('#list').querySelector(`[data-source-focus="${CSS.escape(sourceFocus)}"]`)?.focus({preventScroll:true})});
 if($('.source-strip'))$('.source-strip').scrollLeft=sourceScroll;
 $('#view-horizon').setAttribute('aria-pressed',view==='horizon');$('#view-findings').setAttribute('aria-pressed',view==='findings');$('#view-trail').setAttribute('aria-pressed',view==='trail');$('#list').classList.toggle('activity-list',view==='trail');updateCompare();
}

const horizonExpanded=new Set();
const horizonLenses=[
 ['pilot','01 / TEST','Bounded experiments','A pilot is a recorded judgment. Compare its next test with the baseline before acting.'],
 ['adapt','02 / SHAPE','Mechanisms to adapt','Useful parts that need a local fit before trial.'],
 ['quarry','03 / EXTRACT','Parts worth extracting','Candidate material to separate from the surrounding package.'],
 ['monitor','04 / WATCH','Awaiting new evidence','Revisit when evidence or the need changes.'],
 ['reject','05 / DECLINE','Reasons retained','Keep the reason so the same mistake stays buried.'],
 ['triage','06 / ASSESS','Needs current assessment','Evidence is absent, changed, or not bound to this material.'],
 ['adopt','07 / ACCEPT','Recorded acceptance','Acceptance must be established by its separate production gate.']
];
function horizonCard(r){
 const e=latest(r),s=sourceOf(r),d=disposition(r);
 const mechanism=tags(r).mechanism||e?.capability_delta||r.payload.summary||'No mechanism recorded.';
 const next=e?.next_test||'No current evaluation. Review absent, changed or legacy evidence.';
 return '<article class="horizon-finding" data-disposition="'+esc(d)+'">'+
   '<button class="horizon-open" data-id="'+esc(r.record_id)+'" aria-current="'+(selected?.record_id===r.record_id)+'">'+
   '<span class="horizon-origin">'+esc(s?.payload.title||r.payload.source_key||'Source not recorded')+'</span>'+
   '<strong>'+esc(title(r))+'</strong>'+
   '<span class="horizon-mechanism">'+esc(short(mechanism,160))+'</span>'+
   '<span class="horizon-test-label">'+(e?'NEXT FALSIFIABLE TEST':'EVIDENCE GAP')+'</span>'+
   '<span class="horizon-test">'+esc(short(next,170))+'</span>'+
   '<span class="horizon-open-cue">Inspect evidence ↗</span></button>'+
   '<button class="pin horizon-pin" data-pin="'+esc(r.record_id)+'" aria-pressed="'+pins.has(r.record_id)+'" aria-label="'+(pins.has(r.record_id)?'Remove ':'Add ')+esc(title(r))+(pins.has(r.record_id)?' from':' to')+' comparison">'+(pins.has(r.record_id)?'✓ On bench':'+ Compare')+'</button>'+
   '</article>';
}
function renderHorizon(rs){
 const evaluated=rs.filter(r=>currentEvaluation(r)).length;
 const withTest=rs.filter(r=>Boolean(latest(r)?.next_test)).length;
 const sources=new Set(rs.map(r=>r.payload.source_key).filter(Boolean)).size;
 const measures='<div class="horizon-measures" aria-label="Visible collection facts">'+
  '<div><strong>'+rs.length+'</strong><span>findings in view</span></div>'+
  '<div><strong>'+sources+'</strong><span>sources in view</span></div>'+
  '<div><strong>'+withTest+'</strong><span>next tests recorded</span></div>'+
  '<div><strong>'+String(rs.length-evaluated)+'</strong><span>without current evaluation</span></div></div>';
 const constrained=Boolean(filter||$('#search').value.trim());
 const sections=horizonLenses.map(([id,number,label,explainer])=>{
  const items=rs.filter(r=>disposition(r)===id);
  if(!items.length)return '';
  const shown=(constrained||horizonExpanded.has(id))?items:items.slice(0,3);
  return '<section class="horizon-group" data-disposition="'+id+'" aria-label="'+esc(label)+'">'+
   '<header class="horizon-group-head"><span class="horizon-index">'+number+'</span><div><p class="horizon-category">'+esc(id)+'</p><h2>'+esc(label)+'</h2><p>'+esc(explainer)+'</p></div><strong class="horizon-group-count">'+items.length+'</strong></header>'+
   '<div class="horizon-results">'+shown.map(horizonCard).join('')+'</div>'+
   (shown.length<items.length?'<button class="horizon-expand" data-expand="'+id+'">Show '+(items.length-shown.length)+' more '+esc(id)+' findings ↓</button>':'')+
   '</section>';
 }).join('');
 return measures+'<div class="horizon-field">'+sections+'</div>';
}

function renderBlackglass(rs){
 const groups=new Map();rs.forEach(r=>{const key=r.payload.source_key||'';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r)});
 const sheets=[...groups].map(([key,items],gi)=>{const s=sourceOf(items[0]);return `<section class="expedition"><header class="expedition-head"><span class="expedition-number">${String(gi+1).padStart(2,'0')}</span><div class="source-heading"><p class="eyebrow">SOURCE / ${esc(day(activityDate(items[0])))}</p><button ${s?`data-id="${esc(s.record_id)}"`:''}><h2>${esc(s?.payload.title||key||'Unlinked finding')}</h2><span aria-hidden="true">↗</span></button></div><span class="source-tally">${items.length} extracted<br>${items.length===1?'mechanism':'mechanisms'}</span></header><div class="extraction-grid">${items.map((r,i)=>{const e=latest(r);return `<article class="extraction-card ${selected?.record_id===r.record_id?'selected':''}" data-disposition="${esc(disposition(r))}"><button class="record" data-id="${esc(r.record_id)}" aria-current="${selected?.record_id===r.record_id}"><span class="record-top"><span class="disposition">${esc(disposition(r))}</span><span class="record-date">${String(i+1).padStart(2,'0')} / ${String(items.length).padStart(2,'0')}</span></span><h3 class="record-title">${esc(title(r))}</h3><p class="record-summary">${esc(short(tags(r).mechanism||e?.capability_delta||r.payload.summary,230))}</p><span class="card-test"><span class="eyebrow">${e?'NEXT TEST':'ASSESSMENT'}</span><span>${esc(e?short(e.next_test||'No next test recorded.',150):'No native evaluation recorded.')}</span></span><span class="record-meta">${evaluations(r).length} recorded evaluation${evaluations(r).length===1?'':'s'}<span>Open evidence ↗</span></span></button><button class="pin" data-pin="${esc(r.record_id)}" aria-pressed="${pins.has(r.record_id)}" aria-label="${pins.has(r.record_id)?'Remove':'Add'} ${esc(title(r))} ${pins.has(r.record_id)?'from':'to'} comparison">${pins.has(r.record_id)?'✓ On bench':'+ To bench'}</button></article>`}).join('')}</div></section>`}).join('');
 const unused=!filter&&!$('#search').value.trim()?records.filter(s=>s.record_type==='source'&&!records.some(r=>r.record_type==='candidate'&&r.payload.source_key===s.payload.source_key)):[];
 return `<div class="source-gallery">${sheets}${unused.length?`<details class="registered-sources"><summary>${unused.length} registered sources without linked findings</summary>${unused.map(s=>`<button class="relation" data-id="${esc(s.record_id)}">${esc(title(s))} ↗</button>`).join('')}</details>`:''}</div>`;
}
function drawTrail(rs){const groups=new Map();rs.forEach(r=>{const key=date(r).slice(0,10)||'Undated';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r)});$('#list').innerHTML=[...groups].map(([d,items])=>`<section class="trail-group"><h3>${esc(d==='Undated'?d:day(d))}</h3><div class="trail-events">${items.map(r=>`<button class="trail-event ${selected?.record_id===r.record_id?'selected':''}" data-id="${esc(r.record_id)}" aria-current="${selected?.record_id===r.record_id}"><span class="trail-marker" aria-hidden="true"></span><span class="trail-content"><small>${esc(r.record_type)}${disposition(r)?' · '+esc(disposition(r)):''}</small><h3>${esc(title(r))}</h3><p>${esc(short(r.payload.capability_delta||r.payload.summary||r.payload.notes,130))}</p></span></button>`).join('')}</div></section>`).join('')}
function select(id){
 selected=records.find(r=>r.record_id===id);if(!selected)return;
 const source=sourceOf(selected);if(source)sourceFocus=source.payload.source_key;
 localStorage.setItem(storageKey('selected'),id);draw();detail();
 if(!$('#reading').open)$('#reading').showModal();$('#reading').scrollTop=0;$('#detail').focus({preventScroll:true});
}
function closeReading(){const id=selected?.record_id;$('#reading').close();$('#list').querySelector(`[data-id="${CSS.escape(id||'')}"]`)?.focus()}
function visibleFindings(){const selector=view==='horizon'?'.horizon-open':view==='findings'?(document.body.dataset.skin==='snapframe'?'.mechanism-node':'.extraction-card .record'):'.trail-event';return [...$('#list').querySelectorAll(selector)].map(node=>records.find(r=>r.record_id===node.dataset.id)).filter(r=>r?.record_type==='candidate')}
function navigateFinding(step){const rs=visibleFindings(),i=rs.findIndex(r=>r.record_id===selected?.record_id);if(i>=0&&rs[i+step])select(rs[i+step].record_id)}
function block(label,value,cl=''){return `<article class="${cl}"><p class="eyebrow">${esc(label)}</p><p>${esc(value?text(value):'Not recorded')}</p></article>`}
function locator(v){if(!v)return '<p>Not recorded</p>';try{const u=new URL(v);if(['https:','http:'].includes(u.protocol))return `<a href="${esc(u.href)}" target="_blank" rel="noopener noreferrer">${esc(v)} ↗</a>`}catch{}return `<p class="locator">${esc(v)}</p>`}
function evaluationCard(r,compact=false){const e=r.payload;return `<article class="evaluation-slip"><div class="evaluation-heading"><span class="disposition">${esc(e.disposition)}${r.current_for_candidate?'':' · HISTORICAL'}</span><small>${esc(day(date(r)))}</small></div><p class="small">${esc(r.assessment_state||'Unbound historical assessment')}</p>${Object.entries(r.provenance?.decision_context||{}).map(([key,value])=>block(key.replaceAll('_',' '),value)).join('')}${r.provenance?.decision_gaps?.length?block('Decision gaps',r.provenance.decision_gaps.join('; ')):''}${compact?'':`<h3>${esc(e.capability_delta||'Recorded evaluation')}</h3>`}<div class="next-test"><p class="eyebrow">THE NEXT FALSIFIABLE TEST</p><p>${esc(e.next_test||'No test recorded.')}</p></div>${e.notes?`<details class="judgment-notes"><summary>Read the judgment and its limits</summary><p>${esc(e.notes)}</p></details>`:''}<details class="evidence-details"><summary>Inspect ${e.evidence?.length||0} evidence reference${e.evidence?.length===1?'':'s'} & recorded scores</summary><ul class="evidence-list">${(e.evidence||[]).map(v=>'<li>'+esc(text(v))+'</li>').join('')||'<li>No evidence supplied.</li>'}</ul><p class="small">Priority score: ${esc(e.weighted_score??'not recorded')} · A prioritization aid, not proof of fitness.</p><div class="risk-scores">${Object.entries(e.risk_scores||{}).map(([k,v])=>`<span>${esc(k.replaceAll('_',' '))}: <strong>${esc(v)}/5</strong></span>`).join('')}</div></details></article>`}
function detail(){
 if(!selected){$('#detail').innerHTML='<div class="empty-state"><p class="eyebrow">THE READING BENCH</p><h2>Every useful idea deserves its evidence.</h2><p>Select a finding to recover why it mattered, follow its source, and inspect the next test.</p></div>';return}
 const r=selected,p=r.payload,t=tags(r),es=evaluations(r),e=latest(r),s=sourceOf(r),isCandidate=r.record_type==='candidate';
 $('#reader-path').textContent=(s?.payload.title||'Native record')+' / '+r.record_type;
 const sequence=visibleFindings(),position=sequence.findIndex(x=>x.record_id===r.record_id);$('#previous-finding').disabled=position<1;$('#next-finding').disabled=position<0||position>=sequence.length-1;
 const related=records.filter(x=>x.record_id!==r.record_id&&(r.record_type==='source'?x.payload.source_key===p.source_key:r.record_type==='evaluation'?x.record_type==='candidate'&&x.payload.candidate_key===p.candidate_key:x.record_id===s?.record_id));
 const peers=isCandidate?records.filter(x=>x.record_type==='candidate'&&x.record_id!==r.record_id&&x.payload.source_key===p.source_key):[];
 const rawTags=Array.isArray(p.tags)?p.tags:Array.isArray(t.retained_tags)?t.retained_tags:[];
 const findingSummary=p.summary||p.capability_delta||p.notes||'No summary recorded.';
 const candidateLead=t.mechanism||e?.capability_delta||p.summary;
 const capabilityRepeatsSummary=!t.mechanism&&text(candidateLead).trim()===text(findingSummary).trim();
 $('#detail').innerHTML=`<button class="back-collection" id="back-collection">↑ Back to collection</button><div class="finding-head"><div><p class="eyebrow">${esc(r.record_type)} / ${esc(p.candidate_kind||p.kind||r.source_kind||'recorded work')}</p><h2>${esc(title(r))}</h2><p class="finding-summary">${esc(findingSummary)}</p>${s&&s.record_id!==r.record_id?`<button class="source-link" data-related="${esc(s.record_id)}">Source: ${esc(s.payload.title)} ↗</button>`:''}</div><div class="finding-stamp" data-disposition="${esc(disposition(r))}"><strong>${esc(disposition(r)||'Source record')}</strong><span>Revision ${r.current_version}</span><span>${esc(day(date(r)))}</span></div></div><div class="actions finding-actions">${r.record_type!=='evaluation'?'<button id="revise">Edit record</button>':''}${isCandidate?`<button id="evaluate">Record evaluation</button><button id="handoff">Project handoff ↓</button><button id="detail-pin" aria-pressed="${pins.has(r.record_id)}">${pins.has(r.record_id)?'✓ On comparison bench':'+ Compare'}</button>`:''}<button id="history">Revision history</button></div><div class="finding-body"><div class="finding-paper">${isCandidate?(capabilityRepeatsSummary?'':block(t.mechanism?'THE USEFUL MECHANISM':'THE RECORDED CAPABILITY DELTA',candidateLead,'mechanism-lead'))+(t.why_cared?block('WHY WE CARED',t.why_cared):'')+(t.applicability?block('WHERE IT COULD HELP',t.applicability):'')+(t.project?block('PROJECT CONNECTION',t.project):'')+(rawTags.length?`<div class="topic-tags" aria-label="Recorded topics">${rawTags.map(v=>'<span>'+esc(text(v))+'</span>').join('')}</div>`:''):`<section class="source-account">${block('Recorded account',p.notes||p.capability_delta||p.summary)}</section>`}${isCandidate?`<section class="excavation"><p class="eyebrow">JUDGMENT TRAIL / ${es.length} RECORDED EVALUATION${es.length===1?'':'S'}</p>${es.map((entry,i)=>evaluationCard(entry,i===0&&!t.mechanism)).join('')||'<div class="empty-evidence"><h3>No native evaluation recorded.</h3><p>The finding may contain source evidence or an earlier recorded disposition. A scored assessment and next test have not been captured in this ledger.</p></div>'}</section>`:r.record_type==='evaluation'?evaluationCard(r):''}<div id="history-panel"></div></div><aside class="provenance"><p class="eyebrow">FOLLOW THE SOURCE</p><h3>${esc(s?.payload.title||p.title||'Source trail')}</h3>${locator(p.locator||s?.payload.locator)}${block('Evidence state',p.evidence_state|| (r.record_type==='source'?'Source registered; candidate evidence is separate.':r.source_kind))}${block('Access posture',s?.payload.access_posture||p.access_posture)}${p.license?block('Recorded license',p.license):''}<p class="small">Recorded ${esc(day(date(r)))}<br>Ledger updated ${esc(day(r.updated_at))}</p><div class="related-findings"><p class="eyebrow">RECORDED CONNECTIONS</p>${related.map(x=>`<button class="relation" data-related="${esc(x.record_id)}"><small>${esc(x.record_type)}</small><strong>${esc(title(x))}</strong></button>`).join('')||'<p class="small">No source or candidate link recorded.</p>'}${peers.length?`<p class="eyebrow">FROM THE SAME SOURCE</p>${peers.slice(0,5).map(x=>`<button class="relation" data-related="${esc(x.record_id)}"><small>${esc(disposition(x))}</small><strong>${esc(title(x))}</strong></button>`).join('')}`:''}</div><p class="small">Connections follow recorded keys. Discovery does not establish production fitness.</p></aside></div><details class="native-payload"><summary>Inspect complete native record</summary><pre>${esc(JSON.stringify(r,null,2))}</pre></details>`;
 $('#back-collection').onclick=closeReading;if($('#revise'))$('#revise').onclick=()=>editRecord(r);if($('#evaluate'))$('#evaluate').onclick=()=>evaluation();if($('#handoff'))$('#handoff').onclick=()=>act(()=>download('handoff','finding-to-project.md',{record_id:r.record_id}));if($('#detail-pin'))$('#detail-pin').onclick=()=>togglePin(r.record_id,true);
 $('#history').onclick=()=>act(async()=>{const h=await api('history',{record_id:r.record_id});$('#history-panel').innerHTML='<h3>Preserved native revisions</h3>'+h.history.map(x=>`<details class="revision"><summary>Revision ${esc(x.version??x.version_number??'')} · ${esc(day(x.effective_at||x.recorded_at||x.created_at))}</summary><pre>${esc(JSON.stringify(x,null,2))}</pre></details>`).join('');$('#history-panel').scrollIntoView({behavior:'instant',block:'nearest'})});
 $('#detail').querySelectorAll('[data-related]').forEach(b=>b.onclick=()=>select(b.dataset.related));
}
function togglePin(id,fromDetail=false){if(pins.has(id))pins.delete(id);else{if(pins.size>=3){status('Three findings are already on the bench. Remove one before adding another.');return}pins.add(id)}localStorage.setItem(storageKey('pins'),JSON.stringify([...pins]));draw();if(fromDetail){detail();$('#detail-pin')?.focus({preventScroll:true})}else {if(selected?.record_id===id&&$('#detail-pin')){$('#detail-pin').textContent=pins.has(id)?'✓ On comparison bench':'+ Compare';$('#detail-pin').setAttribute('aria-pressed',pins.has(id))}$('#list').querySelector(`[data-pin="${CSS.escape(id)}"]`)?.focus({preventScroll:true})}status(pins.size+' finding'+(pins.size===1?'':'s')+' on the comparison bench.');if($('#comparison').open)renderComparison()}
function updateCompare(){
 $('#compare-count').textContent=pins.size;$('#compare-open').disabled=pins.size<2;$('#compare-open').title=pins.size<2?'Add at least two findings to compare':'Open comparison bench';
 $('#bench-items').innerHTML=pins.size?[...pins].map(id=>{const r=records.find(x=>x.record_id===id);return `<button class="bench-chip" data-unpin="${esc(id)}" title="Remove from comparison">${esc(short(title(r),55))}<span aria-hidden="true">×</span></button>`}).join(''):'<span class="bench-empty">Add two or three findings to compare their mechanisms and next tests.</span>';
 $('#bench-items').querySelectorAll('[data-unpin]').forEach(b=>b.onclick=()=>togglePin(b.dataset.unpin));
}
function renderComparison(){const rs=[...pins].map(id=>records.find(r=>r.record_id===id)).filter(Boolean);const rows=[['Useful mechanism',r=>tags(r).mechanism||r.payload.summary],['Capability delta',r=>latest(r)?.capability_delta],['Next test / action',r=>latest(r)?.next_test],['Baseline / comparison',r=>JSON.stringify(currentEvaluation(r)?.provenance?.decision_context||{},null,2)],['Why we cared',r=>tags(r).why_cared],['Possible use',r=>tags(r).applicability||tags(r).project],['Evidence state',r=>r.payload.evidence_state],['Evidence',r=>(latest(r)?.evidence||[]).map(text).join('\n\n')],['Costs / risks / judgment',r=>latest(r)?.notes],['Source',r=>r.payload.locator||sourceOf(r)?.payload.locator]];$('#comparison-body').innerHTML=rs.length?`<div class="comparison-table-wrap"><table class="comparison-table"><thead><tr><th scope="col">Decision lens</th>${rs.map(r=>`<th scope="col"><span class="disposition">${esc(disposition(r))}</span><h3>${esc(title(r))}</h3><button data-remove="${esc(r.record_id)}">Remove</button></th>`).join('')}</tr></thead><tbody>${rows.map(([label,fn])=>`<tr><th scope="row">${label}</th>${rs.map(r=>`<td>${esc(text(fn(r)||'Not recorded'))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`:'<div class="empty-state"><h3>The comparison bench is clear.</h3><p>Close this view and add two or three findings.</p></div>';$('#comparison-body').querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{togglePin(b.dataset.remove);$('#compare-close').focus()})}
function field(name,value,multiline=false,required=false){return `<label>${esc(name.replaceAll('_',' '))}${multiline?`<textarea name="${name}" rows="3" ${required?'required':''}>${esc(value??'')}</textarea>`:`<input name="${name}" value="${esc(value??'')}" ${required?'required':''}>`}</label>`}
function openEditor(){document.querySelector('.tools').open=false;$('#form-error').textContent='';$('#edit').showModal()}
function editRecord(r,kind){kind=kind||r?.record_type;const p=r?structuredClone(r.payload):kind==='source'?{source_key:'source_'+Date.now(),title:'',kind:'research',locator:'',access_posture:'manual_read_only',notes:''}:{candidate_key:'candidate_'+Date.now(),source_key:records.find(r=>r.record_type==='source')?.payload.source_key||'',title:'',locator:'',candidate_kind:'workflow',summary:'',candidate_status:'triage',evidence_state:'reported_unverified',tags:{}};const t=typeof p.tags==='object'&&!Array.isArray(p.tags)&&p.tags?p.tags:{retained_tags:p.tags||[]};$('#formtitle').textContent=r?'Revise '+kind:'Record a '+kind;const names=kind==='source'?['source_key','title','kind','locator','access_posture','notes']:kind==='run'?['notes']:['candidate_key','source_key','title','locator','candidate_kind','summary','evidence_state','license','content_hash'];$('#fields').innerHTML=names.map(n=>n==='source_key'&&kind==='candidate'?`<label>Source<select name="source_key" ${r?'disabled':''}>${records.filter(x=>x.record_type==='source').map(s=>`<option value="${esc(s.payload.source_key)}" ${p.source_key===s.payload.source_key?'selected':''}>${esc(title(s))}</option>`).join('')}</select></label>`:field(n,typeof p[n]==='object'?JSON.stringify(p[n]):p[n],['summary','notes'].includes(n),['title','source_key','candidate_key','locator'].includes(n))).join('')+(kind==='candidate'?['why_cared','mechanism','applicability','project'].map(n=>field(n,t[n],true)).join(''):'');if(r){const identity=$('#fields input[name="'+kind+'_key"]');if(identity)identity.readOnly=true}formAction=async f=>{names.forEach(n=>{if(r&&kind==='candidate'&&n==='source_key')return;p[n]=kind==='run'&&typeof p[n]==='object'?JSON.parse(f.get(n)):f.get(n)});if(kind==='candidate'){['why_cared','mechanism','applicability','project'].forEach(n=>t[n]=f.get(n));p.tags=t}selected=r?await api('save',{...r,payload:p}):await api('create',{kind,payload:p});await refresh();status('Saved to the native ledger.');};openEditor()}
function evaluation(){
 const e={positive_scores:{},risk_scores:{},decision_context:{},capability_delta:'',evidence:[],preferred_disposition:'monitor',next_test:'',notes:''};
 const positives=['new_outcome','executable_leverage','domain_judgment','evidence_quality','maintainability','portability','context_efficiency'],risks=['security','privacy','license','cost_dependency','overlap'];
 const context=['baseline','comparison','rights_basis','reason','owner','action_scope'];
 $('#formtitle').textContent='A disposition needs evidence';
 $('#fields').innerHTML='<p>Choose the justified disposition. Scores rank attention; they do not promote your choice. Missing comparison or rights evidence keeps an actionable recommendation in Monitor. This ledger records your assessment; it does not verify your claims.</p>'+['capability_delta','evidence','next_test','notes'].map(n=>field(n,'',true,['capability_delta','evidence'].includes(n))).join('')+`<label>Preferred disposition<select name="preferred_disposition">${['monitor','quarry','adapt','pilot','reject'].map(s=>'<option>'+s+'</option>').join('')}</select></label><h3>Decision basis</h3><p>Baseline: what would you do without this? Comparison: what did the evidence show on that task, and what remains untested? Rights basis: the source and permitted use; a LICENSE filename is insufficient. Owner and action scope name the next responsible destination and authorized work, when known.</p>`+context.map(n=>field(n,'',true)).join('')+`<label>Rights status<select name="rights_status"><option value="unresolved">Unresolved — investigate first</option><option value="compatible">Compatible with the stated use</option><option value="not_applicable">Independent idea; no protected material reused</option><option value="incompatible">Incompatible with the stated use</option></select></label><h3>Benefit scores · 0–5</h3><div class="scoregrid">${positives.map(n=>scoreField(n)).join('')}</div><h3>Risk scores · 0–5</h3><p>Make an explicit choice. 0 means none found in the stated inspection; 5 means severe or unresolved. Unknown is not zero.</p><div class="scoregrid">${risks.map(n=>scoreField(n)).join('')}</div>`;
 formAction=async f=>{positives.forEach(n=>e.positive_scores[n]=Number(f.get(n)));risks.forEach(n=>e.risk_scores[n]=Number(f.get(n)));['capability_delta','next_test','notes','preferred_disposition'].forEach(n=>e[n]=f.get(n));context.concat('rights_status').forEach(n=>e.decision_context[n]=f.get(n));e.evidence=f.get('evidence').split('\n').filter(Boolean);const result=await api('evaluate',{candidate_key:selected.payload.candidate_key,evaluation:e});await refresh();status('Current disposition: '+result.current_disposition+(result.decision_gaps.length?' · Missing: '+result.decision_gaps.join('; '):''))};openEditor()
}
function scoreField(n){return `<label>${esc(n.replaceAll('_',' '))}<input type="number" min="0" max="5" step="1" value="" name="${n}" required></label>`}
async function download(action,name,data={}){const blob=await api(action,data),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);status('Export ready: '+name)}
$('#source').onclick=()=>editRecord(null,'source');$('#candidate').onclick=()=>{if(!records.some(r=>r.record_type==='source')){status('Record a source first so the finding has a provenance trail.');return editRecord(null,'source')}editRecord(null,'candidate')};
$('#form').onsubmit=async e=>{e.preventDefault();const save=$('#form button[type=submit]');save.disabled=true;$('#form-error').textContent='';try{await formAction(new FormData(e.target));$('#edit').close()}catch(err){$('#form-error').textContent=err.message;status(err.message,true)}finally{save.disabled=false}};
$('#cancel').onclick=()=>$('#edit').close();$('#import').onclick=()=>{$('.tools').open=false;$('#file').click()};$('#file').onchange=e=>act(async()=>{const file=e.target.files[0];if(!file)return;try{await api('import',{text:await file.text()});await refresh();status('Manifest imported atomically; native versions and the source digest were recorded.')}finally{e.target.value=''}});$('#export').onclick=()=>act(()=>download('export','praxis-ledger.jsonl'));$('#report').onclick=()=>act(()=>download('report','praxis-report.md'));
$('#filters-toggle').onclick=()=>{const expanded=$('.control-deck').classList.toggle('filters-expanded');$('#filters-toggle').setAttribute('aria-expanded',expanded);$('#filters-toggle').innerHTML=expanded?'Hide filters <span aria-hidden="true">−</span>':'Filter collection <span aria-hidden="true">＋</span>'};
$('#search').oninput=draw;$('#order').onchange=draw;$('#refresh').onclick=refresh;
$('#view-horizon').onclick=()=>{view='horizon';draw()};$('#view-findings').onclick=()=>{view='findings';draw()};$('#view-trail').onclick=()=>{view='trail';draw()};
$('#compare-open').onclick=()=>{renderComparison();$('#comparison').showModal()};$('#compare-close').onclick=()=>$('#comparison').close();
const savedSkin=localStorage.getItem('praxisSkin');$('#skin').value=['blackglass','snapframe'].includes(savedSkin)?savedSkin:'blackglass';document.body.dataset.skin=$('#skin').value;
$('#skin').onchange=e=>{document.body.dataset.skin=e.target.value;localStorage.setItem('praxisSkin',e.target.value);if(e.target.value==='snapframe'&&selected?.payload.source_key)sourceFocus=selected.payload.source_key;draw();detail()};
$('#reading-close').onclick=closeReading;$('#previous-finding').onclick=()=>navigateFinding(-1);$('#next-finding').onclick=()=>navigateFinding(1);
$('#reading').addEventListener('cancel',e=>{e.preventDefault();closeReading()});
document.addEventListener('keydown',e=>{if(e.key==='/'&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)&&!document.querySelector('dialog[open]')){e.preventDefault();$('#search').focus()}if(e.key==='Escape'&&document.activeElement===$('#search')){$('#search').value='';draw()}});
/* SNAPFRAME: native source -> mechanism -> recorded judgment circuits.
 * Returns markup only, apart from retaining the sourceFocus navigation state.
 * Events are delegated by the workspace through data-source-focus/data-id/data-pin.
 */
function renderSnapframe(rs) {
  const findings = rs.filter(r => r.record_type === 'candidate');
  const allFindings = records.filter(r => r.record_type === 'candidate');
  const searchActive = Boolean(document.querySelector('#search')?.value.trim());
  const dispositionActive = typeof filter !== 'undefined' && Boolean(filter);
  const constrained = searchActive || dispositionActive;
  if (!findings.length && (constrained || !records.some(r=>r.record_type==='source'))) {
    const existing = allFindings.length > 0;
    return `<div class="empty-state"><p class="eyebrow">${existing ? 'NO MATCHING MECHANISMS' : 'THE FIRST CIRCUIT'}</p><h3>${existing ? 'Nothing follows this search yet.' : 'A source is where the trail begins.'}</h3><p>${existing ? 'Clear the search and disposition filter to return to your source circuits.' : 'Record a source and finding, or open the native data home containing your earlier mining work. A circuit appears when a finding has a recorded source.'}</p>${existing ? '<button id="clear-all">Show the whole collection</button>' : '<button id="first-source">Record the first source</button><button id="first-import">Import a mining manifest</button>'}</div>`;
  }

  const matchingKeys = new Set(findings.map(r => r.payload.source_key));
  const sources = records.filter(r => r.record_type === 'source' && (!constrained || matchingKeys.has(r.payload.source_key)));
  const sourceFindings = s => findings.filter(r => r.payload.source_key === s.payload.source_key);
  const sourceActivity = s => [date(s), ...sourceFindings(s).map(activityDate)].sort().at(-1) || '';
  sources.sort((a, b) => sourceActivity(b).localeCompare(sourceActivity(a)) || title(a).localeCompare(title(b)));
  if (!sources.length) {
    return '<div class="empty-state"><p class="eyebrow">SOURCE RECORD UNAVAILABLE</p><h3>The mechanisms have no matching source record.</h3><p>Their source keys are retained, but this ledger does not contain the source records needed to draw their circuits. Inspect the native records or refresh the collection.</p></div>';
  }
  if (!sources.some(s => s.payload.source_key === sourceFocus)) {
    const newest = [...findings].sort((a, b) => activityDate(b).localeCompare(activityDate(a)))[0];
    sourceFocus = sources.some(s => s.payload.source_key === newest?.payload.source_key) ? newest.payload.source_key : sources[0].payload.source_key;
  }
  const source = sources.find(s => s.payload.source_key === sourceFocus);
  const paths = sourceFindings(source);
  const allSourceCount = allFindings.filter(r => r.payload.source_key === sourceFocus).length;
  const sourceCount = constrained && paths.length !== allSourceCount ? `${paths.length} of ${allSourceCount} findings match` : `${paths.length} finding${paths.length === 1 ? '' : 's'}`;

  const strip = `<nav class="source-strip" aria-label="Mining sources">${sources.map(s => {
    const count = sourceFindings(s).length;
    const active = s.payload.source_key === sourceFocus;
    return `<button type="button" class="source-tab${active ? ' active' : ''}" data-source-focus="${esc(s.payload.source_key)}" aria-pressed="${active}" title="${esc(title(s))}"><span class="node-caption">${count ? `${count} finding${count === 1 ? '' : 's'}` : 'Registered · no findings'}</span><strong class="node-title">${esc(title(s))}</strong><span class="node-caption">${esc(day(sourceActivity(s)))}</span></button>`;
  }).join('')}</nav>`;

  const sourceNode = `<button type="button" class="source-root${selected?.record_id === source.record_id ? ' selected' : ''}" data-id="${esc(source.record_id)}" aria-current="${selected?.record_id === source.record_id}"><span class="node-caption">SOURCE / ${esc(day(date(source)))}</span><strong class="node-title">${esc(title(source))}</strong><span class="node-caption">${esc(sourceCount)}</span><span class="node-caption">Open source record ↗</span></button>`;

  const pathMarkup = paths.map((r, index) => {
    const evaluation = currentEvaluation(r);
    const judgment = evaluation?.payload;
    const mechanism = tags(r).mechanism || judgment?.capability_delta || r.payload.summary;
    const pinned = pins.has(r.record_id);
    const selectedPath = selected?.record_id === r.record_id || Boolean(evaluation && selected?.record_id === evaluation.record_id);
    const judgmentNode = judgment
      ? `<button type="button" class="judgment-node" data-id="${esc(evaluation.record_id)}" data-disposition="${esc(judgment.disposition)}" aria-current="${selected?.record_id === evaluation.record_id}"><span class="node-caption">RECORDED JUDGMENT / ${esc(day(date(evaluation)))}</span><strong class="node-title">${esc(judgment.disposition)}</strong><span class="node-caption">Next falsifiable test</span><span class="node-test">${esc(short(judgment.next_test || 'No next test recorded.', 200))}</span><span class="node-caption">${judgment.evidence?.length || 0} evidence reference${judgment.evidence?.length === 1 ? '' : 's'} · Open evaluation ↗</span></button>`
      : `<div class="judgment-node missing-evaluation" data-disposition="${esc(disposition(r))}"><span class="node-caption">RECORDED DISPOSITION</span><strong class="node-title">${esc(disposition(r))}</strong><span class="node-test">No current evaluation</span><span class="node-summary">No evaluation is bound to the current material. Open the finding to inspect any historical judgment.</span></div>`;
    return `<article class="decision-path${selectedPath ? ' selected' : ''}" data-disposition="${esc(disposition(r))}" aria-label="${esc(title(r))} evidence circuit"><button type="button" class="mechanism-node" data-id="${esc(r.record_id)}" aria-current="${selected?.record_id === r.record_id}"><span class="node-index">${String(index + 1).padStart(2, '0')}</span><span class="node-caption">MECHANISM / ${esc(r.payload.candidate_kind?.replaceAll('_', ' ') || 'finding')}</span><strong class="node-title">${esc(title(r))}</strong><span class="node-summary">${esc(short(mechanism, 190))}</span><span class="node-caption">${evaluations(r).length} recorded evaluation${evaluations(r).length === 1 ? '' : 's'} · Open finding ↗</span></button>${judgmentNode}<button type="button" class="circuit-pin" data-pin="${esc(r.record_id)}" aria-pressed="${pinned}" aria-label="${pinned ? 'Remove' : 'Add'} ${esc(title(r))} ${pinned ? 'from' : 'to'} comparison">${pinned ? '✓ On bench' : '+ Compare'}</button></article>`;
  }).join('');

  const emptySource = '<div class="empty-state"><p class="eyebrow">REGISTERED SOURCE</p><h3>No findings are linked to this source.</h3><p>Its source record is retained. The ledger records no candidate relationship here, so no mechanism or judgment circuit is drawn.</p></div>';
  return `${strip}<section class="circuit-board" aria-label="Source, mechanism, and recorded judgment">${sourceNode}<div class="path-list">${pathMarkup || emptySource}</div></section>`;
}

refresh();
