# Praxis Mine 1.2.0

Praxis Mine helps you recover useful mechanisms from earlier research and decide which deserves the next experiment. Its collection, evidence reader, activity trail, and comparison bench share the same native SQLite ledger as the conversational skill.

**Blackglass — Crimson** presents findings as a source-grouped extraction gallery. Floating glass cards expose each mechanism and next test; a persistent filter deck narrows the collection. Near-black material, neutral rims, soft falloff, and clean red signals carry the established Blackglass visual language.

**SNAPFRAME** presents a separate evidence circuit: recorded source → finding → latest native judgment and next test. Its horizontal source rail and branching nodes support tracing where an idea came from and what would change its assessment. Empty sources and missing evaluations remain explicit; the renderer does not invent relationships or equate missing evaluation with absent source evidence.

Both environments open records in a focused reader with previous/next navigation and return to the collection. A fixed bench retains two or three findings for comparison. Search, categorical disposition filters, Activity trail, full source and evaluation history, native editing, imports, exports, and project handoff remain available. Retired skin preferences reset to Blackglass — Crimson.

The current work is a same-version presentation repair of v1.2.0's promised distinct environments and collection workflow. It changes the visual architecture without changing native record custody or adoption gates. Version 1.2.0 originally expanded the accepted 1.1.0 rediscovery workspace with overview and direct comparison.

The package contains no owner research ledger or private screenshots. Local rendering, behavior, archive checks, and installation evidence are recorded separately; they do not establish native macOS execution, fresh-customer activation, accessibility conformance, external publication, or owner acceptance.
